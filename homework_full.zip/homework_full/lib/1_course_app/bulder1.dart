class CourseContent1 {
  String courseNumber;
  String mintNumber;
  String curseName;
  bool isAtiviti;
  CourseContent1(
      {required this.courseNumber,
      required this.mintNumber,
      required this.curseName,
      required this.isAtiviti});
}

List<CourseContent1> courseContent1List = [
  CourseContent1(
      courseNumber: "01",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: true),
  CourseContent1(
      courseNumber: "02",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: true),
  CourseContent1(
      courseNumber: "03",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: true),
  CourseContent1(
      courseNumber: "04",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "05",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "06",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "07",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "08",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "09",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "10",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "11",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "12",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "13",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "14",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "15",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "16",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "17",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false),
  CourseContent1(
      courseNumber: "18",
      mintNumber: "5:35",
      curseName: "Welcome to the Course",
      isAtiviti: false)
];
